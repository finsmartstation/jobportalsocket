module.exports={
    database: 'job_portal',
    username: 'root',
    password: '',
    host: 'localhost',
    dialect: 'mysql',
    charset : 'utf8mb4'
}